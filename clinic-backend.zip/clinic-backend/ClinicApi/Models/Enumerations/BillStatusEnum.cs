namespace ClinicApi.Models.Enumerations
{
    public enum BillStatusEnum
    {
        Draft,
        Open,
        Paid,
        Partial,
        Void
    }
}

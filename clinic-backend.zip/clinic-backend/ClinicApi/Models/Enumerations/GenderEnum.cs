namespace ClinicApi.Models.Enumerations
{
    public enum GenderEnum
    {
        Male,
        Female,
        Other,
        PreferNotToSay
    }
}

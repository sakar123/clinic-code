	using System;
	using System.ComponentModel.DataAnnotations;
using ClinicApi.Models.Enumerations;
namespace ClinicApi.Models.DTOs
	{
	    public class StaffDTO
	    {
	        public Guid? id { get; set; } // Optional for create operations
	        // Person properties
	        [Required]
	        [StringLength(50)]
	        public required string first_name { get; set; }
	        [Required]
	        [StringLength(50)]
	        public required string last_name { get; set; }
	        public DateTime? date_of_birth { get; set; }
	        public GenderEnum? gender { get; set; }
	        [StringLength(100)]
	        [EmailAddress]
	        public required string email { get; set; }
	        [StringLength(20)]
	        public required string phone_number { get; set; }
	        [StringLength(500)]
	        public required string address { get; set; }
	        // Staff-specific properties
	        [Required]
	        public Guid role_id { get; set; }
	        public Guid? specialty_id { get; set; }
	        [StringLength(50)]
	        public required string license_number { get; set; }
	        public bool is_active { get; set; } = true;
	    }
	}
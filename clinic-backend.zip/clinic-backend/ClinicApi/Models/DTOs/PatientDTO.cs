	using System;
	using System.ComponentModel.DataAnnotations;
using ClinicApi.Models.Enumerations;
namespace ClinicApi.Models.DTOs
	{
	    public class PatientDTO
	    {
	        public Guid? id { get; set; } // Optional for create operations
	        // Person properties
	        [Required]
	        [StringLength(50)]
	        public required string first_name { get; set; }
	        [Required]
	        [StringLength(50)]
	        public required string last_name { get; set; }
	        public DateTime? date_of_birth { get; set; }
	        public GenderEnum? gender { get; set; }
	        [StringLength(100)]
	        [EmailAddress]
	        public required string email { get; set; }
	        [StringLength(20)]
	        public required string phone_number { get; set; }
	        [StringLength(500)]
	        public required string address { get; set; }
	        // Patient-specific properties
	        [StringLength(100)]
	        public string? emergency_contact_name { get; set; }
	        [StringLength(20)]
	        public string? emergency_contact_phone { get; set; }
	    }
	}
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.Entities;
using ClinicApi.Models.DTOs;
namespace ClinicApi.Services.Implementations
{
    public class PatientService : IPatientService
    {
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<Person> _personRepository;
        private readonly IMapper _mapper;
        public PatientService(
            IRepository<Patient> patientRepository,
            IRepository<Person> personRepository,
            IMapper mapper)
        {
            _patientRepository = patientRepository;
            _personRepository = personRepository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<PatientDTO>> GetAllPatientsAsync()
        {
            var patients = await _patientRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<PatientDTO>>(patients);
        }
        public async Task<PatientDTO> GetPatientByIdAsync(Guid id)
        {
            var patient = await _patientRepository.GetByIdAsync(id);
            return _mapper.Map<PatientDTO>(patient);
        }
        public async Task<PatientDTO> CreatePatientAsync(PatientDTO patientDto)
        {
            // Create Person first
            var person = _mapper.Map<Person>(patientDto);
            await _personRepository.AddAsync(person);
            await _personRepository.SaveChangesAsync();
            // Create Patient
            var patient = _mapper.Map<Patient>(patientDto);
            patient.person_id = person.id;
            await _patientRepository.AddAsync(patient);
            await _patientRepository.SaveChangesAsync();
            var createdPatient = await _patientRepository.GetByIdAsync(patient.id);
            return _mapper.Map<PatientDTO>(createdPatient);
        }
        public async Task<PatientDTO> UpdatePatientAsync(Guid id, PatientDTO patientDto)
        {
            var existingPatient = await _patientRepository.GetByIdAsync(id);
            if (existingPatient == null)
                throw new KeyNotFoundException("Patient not found");
            var existingPerson = await _personRepository.GetByIdAsync(existingPatient.person_id);
            if (existingPerson == null)
                throw new KeyNotFoundException("Person not found");
            // Update Person
            _mapper.Map(patientDto, existingPerson);
            _personRepository.Update(existingPerson);
            await _personRepository.SaveChangesAsync();
            // Update Patient
            _mapper.Map(patientDto, existingPatient);
            _patientRepository.Update(existingPatient);
            await _patientRepository.SaveChangesAsync();
            var updatedPatient = await _patientRepository.GetByIdAsync(id);
            return _mapper.Map<PatientDTO>(updatedPatient);
        }
        public async Task<bool> DeletePatientAsync(Guid id)
        {
            var patient = await _patientRepository.GetByIdAsync(id);
            if (patient == null)
                return false;
            var person = await _personRepository.GetByIdAsync(patient.person_id);
            if (person != null)
            {
                _personRepository.Delete(person);
                await _personRepository.SaveChangesAsync();
            }
            _patientRepository.Delete(patient);
            await _patientRepository.SaveChangesAsync();
            return true;
        }
    }
}
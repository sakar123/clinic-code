using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;
using ClinicApi.Models.Enumerations;


namespace ClinicApi.Services.Implementations
{
    public class AppointmentService : IAppointmentService
    {
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<AppointmentStatus> _statusRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<Staff> _staffRepository;
        private readonly IMapper _mapper;

        public AppointmentService(
            IRepository<Appointment> appointmentRepository,
            IRepository<AppointmentStatus> statusRepository,
            IRepository<Patient> patientRepository,
            IRepository<Staff> staffRepository,
            IMapper mapper)
        {
            _appointmentRepository = appointmentRepository;
            _statusRepository = statusRepository;
            _patientRepository = patientRepository;
            _staffRepository = staffRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<AppointmentDTO>> GetAllAppointmentsAsync()
        {
            var appointments = await _appointmentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<AppointmentDTO>>(appointments);
        }

        public async Task<AppointmentDTO> GetAppointmentByIdAsync(Guid id)
        {
            var appointment = await _appointmentRepository.GetByIdAsync(id);
            return _mapper.Map<AppointmentDTO>(appointment);
        }

        public async Task<AppointmentDTO> CreateAppointmentAsync(AppointmentDTO appointmentDto)
        {
            // Validate related entities exist
            if (!await _patientRepository.ExistsAsync(appointmentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _staffRepository.ExistsAsync(appointmentDto.staff_id))
                throw new KeyNotFoundException("Staff not found");
                
            if (!await _statusRepository.ExistsAsync(appointmentDto.status_id))
                throw new KeyNotFoundException("Appointment status not found");

            var appointment = _mapper.Map<Appointment>(appointmentDto);
            await _appointmentRepository.AddAsync(appointment);
            await _appointmentRepository.SaveChangesAsync();
            
            return _mapper.Map<AppointmentDTO>(appointment);
        }

        public async Task<AppointmentDTO> UpdateAppointmentAsync(Guid id, AppointmentDTO appointmentDto)
        {
            var existingAppointment = await _appointmentRepository.GetByIdAsync(id);
            if (existingAppointment == null)
                throw new KeyNotFoundException("Appointment not found");

            // Validate related entities exist
            if (!await _patientRepository.ExistsAsync(appointmentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _staffRepository.ExistsAsync(appointmentDto.staff_id))
                throw new KeyNotFoundException("Staff not found");
                
            if (!await _statusRepository.ExistsAsync(appointmentDto.status_id))
                throw new KeyNotFoundException("Appointment status not found");

            _mapper.Map(appointmentDto, existingAppointment);
            existingAppointment.updated_at = DateTime.UtcNow;
            
            _appointmentRepository.Update(existingAppointment);
            await _appointmentRepository.SaveChangesAsync();
            
            return _mapper.Map<AppointmentDTO>(existingAppointment);
        }

        public async Task<bool> DeleteAppointmentAsync(Guid id)
        {
            var appointment = await _appointmentRepository.GetByIdAsync(id);
            if (appointment == null)
                return false;

            _appointmentRepository.Delete(appointment);
            await _appointmentRepository.SaveChangesAsync();
            return true;
        }
    }
}

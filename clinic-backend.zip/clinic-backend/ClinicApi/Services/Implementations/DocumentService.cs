using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;

namespace ClinicApi.Services.Implementations
{
    public class DocumentService : IDocumentService
    {
        private readonly IRepository<Document> _documentRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<DocumentType> _documentTypeRepository;
        private readonly IRepository<Tooth> _toothRepository;
        private readonly IRepository<Treatment> _treatmentRepository;
        private readonly IMapper _mapper;

        public DocumentService(
            IRepository<Document> documentRepository,
            IRepository<Patient> patientRepository,
            IRepository<DocumentType> documentTypeRepository,
            IRepository<Tooth> toothRepository,
            IRepository<Treatment> treatmentRepository,
            IMapper mapper)
        {
            _documentRepository = documentRepository;
            _patientRepository = patientRepository;
            _documentTypeRepository = documentTypeRepository;
            _toothRepository = toothRepository;
            _treatmentRepository = treatmentRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<DocumentDTO>> GetAllDocumentsAsync()
        {
            var documents = await _documentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<DocumentDTO>>(documents);
        }

        public async Task<DocumentDTO> GetDocumentByIdAsync(Guid id)
        {
            var document = await _documentRepository.GetByIdAsync(id);
            return _mapper.Map<DocumentDTO>(document);
        }

        public async Task<DocumentDTO> CreateDocumentAsync(DocumentDTO documentDto)
        {
            if (!await _patientRepository.ExistsAsync(documentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _documentTypeRepository.ExistsAsync(documentDto.document_type_id))
                throw new KeyNotFoundException("Document type not found");
                
            if (documentDto.tooth_id.HasValue && !await _toothRepository.ExistsAsync(documentDto.tooth_id.Value))
                throw new KeyNotFoundException("Tooth not found");
                
            if (documentDto.treatment_id.HasValue && !await _treatmentRepository.ExistsAsync(documentDto.treatment_id.Value))
                throw new KeyNotFoundException("Treatment not found");

            var document = _mapper.Map<Document>(documentDto);
            await _documentRepository.AddAsync(document);
            await _documentRepository.SaveChangesAsync();
            
            return _mapper.Map<DocumentDTO>(document);
        }

        public async Task<DocumentDTO> UpdateDocumentAsync(Guid id, DocumentDTO documentDto)
        {
            var existingDocument = await _documentRepository.GetByIdAsync(id);
            if (existingDocument == null)
                throw new KeyNotFoundException("Document not found");

            if (!await _patientRepository.ExistsAsync(documentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _documentTypeRepository.ExistsAsync(documentDto.document_type_id))
                throw new KeyNotFoundException("Document type not found");
                
            if (documentDto.tooth_id.HasValue && !await _toothRepository.ExistsAsync(documentDto.tooth_id.Value))
                throw new KeyNotFoundException("Tooth not found");
                
            if (documentDto.treatment_id.HasValue && !await _treatmentRepository.ExistsAsync(documentDto.treatment_id.Value))
                throw new KeyNotFoundException("Treatment not found");

            _mapper.Map(documentDto, existingDocument);
            existingDocument.updated_at = DateTime.UtcNow;
            
            _documentRepository.Update(existingDocument);
            await _documentRepository.SaveChangesAsync();
            
            return _mapper.Map<DocumentDTO>(existingDocument);
        }

        public async Task<bool> DeleteDocumentAsync(Guid id)
        {
            var document = await _documentRepository.GetByIdAsync(id);
            if (document == null)
                return false;

            _documentRepository.Delete(document);
            await _documentRepository.SaveChangesAsync();
            return true;
        }
    }
}

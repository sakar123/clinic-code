using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;

namespace ClinicApi.Services.Implementations
{
    public class BillingService : IBillingService
    {
        private readonly IRepository<Billing> _billingRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IMapper _mapper;

        public BillingService(
            IRepository<Billing> billingRepository,
            IRepository<Patient> patientRepository,
            IMapper mapper)
        {
            _billingRepository = billingRepository;
            _patientRepository = patientRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<BillingDTO>> GetAllBillingsAsync()
        {
            var billings = await _billingRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<BillingDTO>>(billings);
        }

        public async Task<BillingDTO> GetBillingByIdAsync(Guid id)
        {
            var billing = await _billingRepository.GetByIdAsync(id);
            return _mapper.Map<BillingDTO>(billing);
        }

        public async Task<BillingDTO> CreateBillingAsync(BillingDTO billingDto)
        {
            if (!await _patientRepository.ExistsAsync(billingDto.patient_id))
                throw new KeyNotFoundException("Patient not found");

            var billing = _mapper.Map<Billing>(billingDto);
            await _billingRepository.AddAsync(billing);
            await _billingRepository.SaveChangesAsync();
            
            return _mapper.Map<BillingDTO>(billing);
        }

        public async Task<BillingDTO> UpdateBillingAsync(Guid id, BillingDTO billingDto)
        {
            var existingBilling = await _billingRepository.GetByIdAsync(id);
            if (existingBilling == null)
                throw new KeyNotFoundException("Billing not found");

            if (!await _patientRepository.ExistsAsync(billingDto.patient_id))
                throw new KeyNotFoundException("Patient not found");

            _mapper.Map(billingDto, existingBilling);
            existingBilling.updated_at = DateTime.UtcNow;
            
            _billingRepository.Update(existingBilling);
            await _billingRepository.SaveChangesAsync();
            
            return _mapper.Map<BillingDTO>(existingBilling);
        }

        public async Task<bool> DeleteBillingAsync(Guid id)
        {
            var billing = await _billingRepository.GetByIdAsync(id);
            if (billing == null)
                return false;

            _billingRepository.Delete(billing);
            await _billingRepository.SaveChangesAsync();
            return true;
        }
    }
}

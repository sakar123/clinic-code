using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;

namespace ClinicApi.Services.Implementations
{
    public class SpecialtyService : ISpecialtyService
    {
        private readonly IRepository<Specialty> _specialtyRepository;
        private readonly IMapper _mapper;

        public SpecialtyService(IRepository<Specialty> specialtyRepository, IMapper mapper)
        {
            _specialtyRepository = specialtyRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SpecialtyDTO>> GetAllSpecialtiesAsync()
        {
            var specialties = await _specialtyRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<SpecialtyDTO>>(specialties);
        }

        public async Task<SpecialtyDTO> GetSpecialtyByIdAsync(Guid id)
        {
            var specialty = await _specialtyRepository.GetByIdAsync(id);
            return _mapper.Map<SpecialtyDTO>(specialty);
        }

        public async Task<SpecialtyDTO> CreateSpecialtyAsync(SpecialtyDTO specialtyDto)
        {
            var specialty = _mapper.Map<Specialty>(specialtyDto);
            await _specialtyRepository.AddAsync(specialty);
            await _specialtyRepository.SaveChangesAsync();
            return _mapper.Map<SpecialtyDTO>(specialty);
        }

        public async Task<SpecialtyDTO> UpdateSpecialtyAsync(Guid id, SpecialtyDTO specialtyDto)
        {
            var existingSpecialty = await _specialtyRepository.GetByIdAsync(id);
            if (existingSpecialty == null)
                throw new KeyNotFoundException("Specialty not found");

            _mapper.Map(specialtyDto, existingSpecialty);
            _specialtyRepository.Update(existingSpecialty);
            await _specialtyRepository.SaveChangesAsync();
            return _mapper.Map<SpecialtyDTO>(existingSpecialty);
        }

        public async Task<bool> DeleteSpecialtyAsync(Guid id)
        {
            var specialty = await _specialtyRepository.GetByIdAsync(id);
            if (specialty == null)
                return false;

            _specialtyRepository.Delete(specialty);
            await _specialtyRepository.SaveChangesAsync();
            return true;
        }
    }
}

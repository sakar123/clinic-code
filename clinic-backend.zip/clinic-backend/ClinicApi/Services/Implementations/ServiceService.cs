using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;

namespace ClinicApi.Services.Implementations
{
    public class ServiceService : IServiceService
    {
        private readonly IRepository<Service> _serviceRepository;
        private readonly IRepository<Specialty> _specialtyRepository;
        private readonly IMapper _mapper;

        public ServiceService(
            IRepository<Service> serviceRepository,
            IRepository<Specialty> specialtyRepository,
            IMapper mapper)
        {
            _serviceRepository = serviceRepository;
            _specialtyRepository = specialtyRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<ServiceDTO>> GetAllServicesAsync()
        {
            var services = await _serviceRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<ServiceDTO>>(services);
        }

        public async Task<ServiceDTO> GetServiceByIdAsync(Guid id)
        {
            var service = await _serviceRepository.GetByIdAsync(id);
            return _mapper.Map<ServiceDTO>(service);
        }

        public async Task<ServiceDTO> CreateServiceAsync(ServiceDTO serviceDto)
        {
            if (serviceDto.specialty_id.HasValue && !await _specialtyRepository.ExistsAsync(serviceDto.specialty_id.Value))
                throw new KeyNotFoundException("Specialty not found");

            var service = _mapper.Map<Service>(serviceDto);
            await _serviceRepository.AddAsync(service);
            await _serviceRepository.SaveChangesAsync();
            
            return _mapper.Map<ServiceDTO>(service);
        }

        public async Task<ServiceDTO> UpdateServiceAsync(Guid id, ServiceDTO serviceDto)
        {
            var existingService = await _serviceRepository.GetByIdAsync(id);
            if (existingService == null)
                throw new KeyNotFoundException("Service not found");

            if (serviceDto.specialty_id.HasValue && !await _specialtyRepository.ExistsAsync(serviceDto.specialty_id.Value))
                throw new KeyNotFoundException("Specialty not found");

            _mapper.Map(serviceDto, existingService);
            _serviceRepository.Update(existingService);
            await _serviceRepository.SaveChangesAsync();
            
            return _mapper.Map<ServiceDTO>(existingService);
        }

        public async Task<bool> DeleteServiceAsync(Guid id)
        {
            var service = await _serviceRepository.GetByIdAsync(id);
            if (service == null)
                return false;

            _serviceRepository.Delete(service);
            await _serviceRepository.SaveChangesAsync();
            return true;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;

namespace ClinicApi.Services.Implementations
{
    public class PrescriptionService : IPrescriptionService
    {
        private readonly IRepository<Prescription> _prescriptionRepository;
        private readonly IRepository<Treatment> _treatmentRepository;
        private readonly IMapper _mapper;

        public PrescriptionService(
            IRepository<Prescription> prescriptionRepository,
            IRepository<Treatment> treatmentRepository,
            IMapper mapper)
        {
            _prescriptionRepository = prescriptionRepository;
            _treatmentRepository = treatmentRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<PrescriptionDTO>> GetAllPrescriptionsAsync()
        {
            var prescriptions = await _prescriptionRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<PrescriptionDTO>>(prescriptions);
        }

        public async Task<PrescriptionDTO> GetPrescriptionByIdAsync(Guid id)
        {
            var prescription = await _prescriptionRepository.GetByIdAsync(id);
            return _mapper.Map<PrescriptionDTO>(prescription);
        }

        public async Task<PrescriptionDTO> CreatePrescriptionAsync(PrescriptionDTO prescriptionDto)
        {
            if (!await _treatmentRepository.ExistsAsync(prescriptionDto.treatment_id))
                throw new KeyNotFoundException("Treatment not found");

            var prescription = _mapper.Map<Prescription>(prescriptionDto);
            await _prescriptionRepository.AddAsync(prescription);
            await _prescriptionRepository.SaveChangesAsync();
            
            return _mapper.Map<PrescriptionDTO>(prescription);
        }

        public async Task<PrescriptionDTO> UpdatePrescriptionAsync(Guid id, PrescriptionDTO prescriptionDto)
        {
            var existingPrescription = await _prescriptionRepository.GetByIdAsync(id);
            if (existingPrescription == null)
                throw new KeyNotFoundException("Prescription not found");

            if (!await _treatmentRepository.ExistsAsync(prescriptionDto.treatment_id))
                throw new KeyNotFoundException("Treatment not found");

            _mapper.Map(prescriptionDto, existingPrescription);
            existingPrescription.updated_at = DateTime.UtcNow;
            
            _prescriptionRepository.Update(existingPrescription);
            await _prescriptionRepository.SaveChangesAsync();
            
            return _mapper.Map<PrescriptionDTO>(existingPrescription);
        }

        public async Task<bool> DeletePrescriptionAsync(Guid id)
        {
            var prescription = await _prescriptionRepository.GetByIdAsync(id);
            if (prescription == null)
                return false;

            _prescriptionRepository.Delete(prescription);
            await _prescriptionRepository.SaveChangesAsync();
            return true;
        }
    }
}

using AutoMapper;
using ClinicApi.Models.Entities;
using ClinicApi.Models.DTOs;

namespace ClinicApi.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Appointment, AppointmentDTO>();
            CreateMap<AppointmentStatus, AppointmentStatusDTO>();
            CreateMap<Billing, BillingDTO>();
            CreateMap<BillingLineItem, BillingLineItemDTO>();
            CreateMap<DiscountType, DiscountTypeDTO>();
            CreateMap<Document, DocumentDTO>();
            CreateMap<DocumentType, DocumentTypeDTO>();
            CreateMap<SaleItem, SaleItemDTO>();
            CreateMap<Payment, PaymentDTO>();
            CreateMap<Person, PersonDTO>();
            CreateMap<Prescription, PrescriptionDTO>();
            CreateMap<Service, ServiceDTO>();
            CreateMap<Specialty, SpecialtyDTO>();
            CreateMap<Staff, StaffDTO>();
            CreateMap<Tooth, ToothDTO>();
            CreateMap<ToothStatus, ToothStatusDTO>();
            CreateMap<Role, RoleDTO>();
            CreateMap<Patient, PatientDTO>();
            
            // Add other mappings here
        }
    }
}

namespace Clinic_Api.Test;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}